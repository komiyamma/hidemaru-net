/*
 * This codes is licensed under CC0 1.0 Universal
 */

#pragma once

#include <tchar.h>

using namespace System;

void OutputDebugStream(const TCHAR *format, ...);
void OutputDebugStream(String^ message);