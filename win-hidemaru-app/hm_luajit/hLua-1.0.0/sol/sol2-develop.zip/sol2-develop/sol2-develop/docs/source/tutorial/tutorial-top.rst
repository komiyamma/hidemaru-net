tutorial
========

Take some time to learn the framework with thse tutorials. But, if you need to get going FAST, try using the :doc:`quick 'n' dirty<all-the-things>` approach and your browser's / editors search function.


.. toctree::
   :caption: Sol Tutorial
   :name: tutorialtoc
   :maxdepth: 1

   all-the-things
   getting-started
   existing
   variables
   functions
   cxx-in-lua
   ownership
